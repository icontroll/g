# Installation
> `npm install --save @types/webgl-ext`

# Summary
This package contains type definitions for WebGL Extensions (http://webgl.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webgl-ext

Additional Details
 * Last updated: Tue, 23 Oct 2018 17:03:26 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Arthur Langereis <https://github.com/zenmumbler>.
