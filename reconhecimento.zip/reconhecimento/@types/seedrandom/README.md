# Installation
> `npm install --save @types/seedrandom`

# Summary
This package contains type definitions for seedrandom 2.4.2 (https://github.com/davidbau/seedrandom).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/seedrandom

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: UMD
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: seedrandom

# Credits
These definitions were written by Kern Handa <https://github.com/kernhanda>.
